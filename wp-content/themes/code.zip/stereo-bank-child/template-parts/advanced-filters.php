<?php $hide_empty = true; ?>
<form class="product-page-filter advanced-filters" action="/products/" method="get">
	<div class="product-page-filter-container">	
		<?php
		$types = get_terms([
			'taxonomy' => 'theme_product_type',
			'orderby' => 'name',
			'order' => 'ASC',
			'hide_empty' => $hide_empty
		]);
		?>
		<?php if($types) : ?>
			<div class="product-page-filter-item" data-filter-by="theme_product_type">
				<div class="product-page-filter-top">
					<div class="label">select type</div>
					<div class="title">
						<span>all types</span>
						<div class="icon">
							<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.92512 5.63719L2.69562 4.87054L8.36099 10.5359L14.02 4.87054L14.7969 5.63719L8.36099 12.0731L1.92511 5.63719L1.92512 5.63719Z" fill="black"/></svg>
						</div>
					</div> 
				</div>
				<div class="product-page-filter-body">
					<?php foreach($types as $type) : ?>
						<div class="checked-item">
							<input type="checkbox" name="product_types[]" id="<?php echo $type->slug; ?>" value="<?php echo $type->slug; ?>">
							<label for="<?php echo $type->slug; ?>"><?php echo $type->name; ?></label>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
		
		<?php
		$tones = get_terms([
			'taxonomy' => 'product_tones',
			'orderby' => 'name',
			'order' => 'ASC',
			'hide_empty' => $hide_empty
		]);
		?>
		<?php if($tones) : ?>
			<div class="product-page-filter-item" data-filter-by="product_tones">
				<div class="product-page-filter-top">
					<div class="label">select tone</div>
					<div class="title">
						<span>all tones</span>
						<div class="icon">
							<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.92512 5.63719L2.69562 4.87054L8.36099 10.5359L14.02 4.87054L14.7969 5.63719L8.36099 12.0731L1.92511 5.63719L1.92512 5.63719Z" fill="black"/></svg>
						</div>
					</div> 
				</div>
				<div class="product-page-filter-body">
					<?php foreach($tones as $tone) : ?>
						<div class="checked-item">
							<input type="checkbox" name="product_tones[]" id="<?php echo $tone->slug; ?>" value="<?php echo $tone->slug; ?>">
							<label for="<?php echo $tone->slug; ?>"><?php echo $tone->name; ?></label>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
		
		<?php
		$materials = get_terms([
			'taxonomy' => 'product_materials',
			'orderby' => 'name',
			'order' => 'ASC',
			'hide_empty' => $hide_empty
		]);
		?>
		<?php if($materials) : ?>
			<div class="product-page-filter-item" data-filter-by="product_materials">
				<div class="product-page-filter-top">
					<div class="label">select Material</div>
					<div class="title">
						<span>all Materials</span>
						<div class="icon">
							<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.92512 5.63719L2.69562 4.87054L8.36099 10.5359L14.02 4.87054L14.7969 5.63719L8.36099 12.0731L1.92511 5.63719L1.92512 5.63719Z" fill="black"/></svg>
						</div>
					</div> 
				</div>
				<div class="product-page-filter-body">
					<?php foreach($materials as $material) : ?>
						<div class="checked-item">
							<input type="checkbox" name="product_materials[]" id="<?php echo $material->slug; ?>" value="<?php echo $material->slug; ?>">
							<label for="<?php echo $material->slug; ?>"><?php echo $material->name; ?></label>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
		
		<?php
		$finishes = get_terms([
			'taxonomy' => 'product_finishes',
			'orderby' => 'name',
			'order' => 'ASC',
			'hide_empty' => $hide_empty
		]);
		?>
		<?php if($finishes) : ?>
			<div class="product-page-filter-item" data-filter-by="product_finishes">
				<div class="product-page-filter-top">
					<div class="label">select finish</div>
					<div class="title">
						<span>all Finishes</span>
						<div class="icon">
							<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.92512 5.63719L2.69562 4.87054L8.36099 10.5359L14.02 4.87054L14.7969 5.63719L8.36099 12.0731L1.92511 5.63719L1.92512 5.63719Z" fill="black"/></svg>
						</div>
					</div> 
				</div>
				<div class="product-page-filter-body">
					<?php foreach($finishes as $finish) : ?>
						<div class="checked-item">
							<input type="checkbox" name="product_finishes[]" id="<?php echo $finish->slug; ?>" value="<?php echo $finish->slug; ?>">
							<label for="<?php echo $finish->slug; ?>"><?php echo $finish->name; ?></label>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
		
		<?php
		$sizes = get_terms([
			'taxonomy' => 'product_size',
			'orderby' => 'name',
			'order' => 'ASC',
			'hide_empty' => $hide_empty
		]);
		?>
		<?php if($sizes) : ?>
			<div class="product-page-filter-item" data-filter-by="product_size">
				<div class="product-page-filter-top">
					<div class="label">select size</div>
					<div class="title">
						<span>all sizes</span>
						<div class="icon">
							<svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.92512 5.63719L2.69562 4.87054L8.36099 10.5359L14.02 4.87054L14.7969 5.63719L8.36099 12.0731L1.92511 5.63719L1.92512 5.63719Z" fill="black"/></svg>
						</div>
					</div> 
				</div>
				<div class="product-page-filter-body">
					<?php foreach($sizes as $size) : ?>
						<div class="checked-item">
							<input type="checkbox" name="product_sizes[]" id="<?php echo $size->slug; ?>" value="<?php echo $size->slug; ?>">
							<label for="<?php echo $size->slug; ?>"><?php echo $size->name; ?></label>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endif; ?>
		
		<button class="filter-submit" type="submit" disabled>
			Advanced search
			<svg xmlns="http://www.w3.org/2000/svg" width="10" height="11" viewBox="0 0 10 11" fill="none"><path d="M7.85076 1.75373H0.447762V0.5H10V10.0522H8.74628V2.64926L0.895523 10.5L0 9.60449L7.85076 1.75373Z" fill="#828282"/></svg>
		</button>
	</div>
</form>