<?php 
$hide_empty = true;

//get all products ids
$products_ids = [];
$args = array(
	'post_type' => 'product',
	'post_status' => 'publish',
	'posts_per_page' => -1,
	'fields' => 'ids'
);
$args['tax_query'] = stone_find_get_parameters();
$products_ids = get_posts($args);
?>

<div class="elementor-widget-cmsmasters-theme-blog-grid__header-side cmsmasters-filter-nav-multiple">
	<div class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-popup-close">
		<h2>Filter by</h2>
		<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-popup-close-icon themeicon- theme-icon-close"></i>
	</div>
	<div class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-clear-all-button">Clear All</div>	
	
	<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list">
		<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item" data-taxonomy-id="sorting">
			<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-wrap">
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-label">Sort by</span>
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger">
					<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value" data-default="Latest">Latest</span>
					<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon themeicon- theme-icon-arrow-forward"></i>
				</span>
			</span>
			<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list sorting ps">
				<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item checked" data-category-id="date">
					<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="radio" id="latest" name="sorting" value="Latest">
					<label for="latest">Latest</label>
					<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
				</li>
				<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item" data-category-id="meta_value_num">
					<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="radio" id="popular" name="sorting" value="Popular">
					<label for="popular">Popular</label>
					<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
				</li>
			</ul>
		</li>
		
		<?php
		$collections = get_terms([
			'taxonomy' => 'collection',
			'orderby' => 'name',
			'order' => 'ASC',
			'object_ids' => $products_ids,
			'hide_empty' => $hide_empty
		]);
		$GET_collections = $_GET["collections"];
		if($GET_collections || (is_array($GET_collections) && !empty($GET_collections))) $collections_active = true;
		else $collections_active = false;
		?>
		<?php if($collections) : ?>
			<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item" data-taxonomy-id="collection">
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-wrap">
					<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger <?php echo($product_types_active) ? 'active':'default-value'; ?>">
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value" data-default="ALL Collection" data-more="0">
							<?php 
							if(!isset($GET_collections) || empty($GET_collections))  echo 'ALL Collection';
							elseif(is_array($GET_collections)) {
								if(count($GET_collections) == 1) echo $GET_collections[0];
								else echo $GET_collections[0] . ' + 1';
							}
							?>								
						</span>
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear-wrap">
							<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear">Clear</span>
							<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon themeicon- theme-icon-arrow-forward"></i>
						</span>
					</span>
				</span>
				<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list ps" <?php echo($collections_active) ? 'style="display:block;"':''; ?>>
					<?php foreach($collections as $collection) : ?>
						<?php
						$checked = false;
						if((is_array($GET_collections) && in_array($collection->slug, $GET_collections)) || $GET_collections == $collection->slug) $checked = true;
						?>
						<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item <?php echo($checked) ? 'checked':''; ?>" data-category-id="<?php echo $collection->term_id; ?>">
							<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="checkbox" id="<?php echo $collection->term_id; ?>" name="<?php echo $collection->name; ?>" value="<?php echo $collection->name; ?>" <?php echo($checked) ? 'checked':''; ?>>
							<label for="<?php echo $collection->term_id; ?>"><?php echo $collection->name; ?></label>
							<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
						</li>
					<?php endforeach; ?>
				</ul>
			</li>
		<?php endif; ?>
		
		
		<?php
		$product_types = get_terms([
			'taxonomy' => 'theme_product_type',
			'orderby' => 'name',
			'order' => 'ASC',
			'object_ids' => $products_ids,
			'hide_empty' => $hide_empty
		]);
		
		
		
		$GET_product_types = $_GET["product_types"];
		if($GET_product_types || (is_array($GET_product_types) && !empty($GET_product_types))) $product_types_active = true;
		else $product_types_active = false;
		?>
		
		<?php if($product_types) : ?>
			<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item" data-taxonomy-id="theme_product_type">
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-wrap">
					<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger <?php echo($product_types_active) ? 'active':'default-value'; ?>">
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value" data-default="all types" data-more="0">
							<?php 
							if(!isset($GET_product_types) || empty($GET_product_types))  echo 'all types';
							elseif(is_array($GET_product_types)) {
								if(count($GET_product_types) == 1) echo $GET_product_types[0];
								else echo $GET_product_types[0] . ' + 1';
							}
							?>						
						</span>
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear-wrap">
							<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear">Clear</span>
							<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon themeicon- theme-icon-arrow-forward"></i>
						</span>
					</span>
				</span>
				<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list ps" <?php echo($product_types_active) ? 'style="display:block;"':''; ?>>
					<?php foreach($product_types as $product_type) : ?>
						<?php
						$checked = false;
						if((is_array($GET_product_types) && in_array($product_type->slug, $GET_product_types)) || $GET_product_types == $product_type->slug) $checked = true;
						?>
						<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item <?php echo($checked) ? 'checked':''; ?>" data-category-id="<?php echo $product_type->term_id; ?>">
							<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="checkbox" id="<?php echo $product_type->term_id; ?>" name="<?php echo $product_type->name; ?>" value="<?php echo $product_type->name; ?>" <?php echo($checked) ? 'checked':''; ?>>
							<label for="<?php echo $product_type->term_id; ?>"><?php echo $product_type->name; ?></label>
							<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
						</li>
					<?php endforeach; ?>
				</ul>
			</li>
		<?php endif; ?>
		
		<?php
		$product_tones = get_terms([
			'taxonomy' => 'product_tones',
			'orderby' => 'name',
			'order' => 'ASC',
			'object_ids' => $products_ids,
			'hide_empty' => $hide_empty
		]);
		
		$GET_product_tones = $_GET["product_tones"];
		if($GET_product_tones || (is_array($GET_product_tones) && !empty($GET_product_tones))) $product_tones_active = true;
		else $product_tones_active = false;
		?>
		
		<?php if($product_tones) : ?>
			<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item" data-taxonomy-id="product_tones">
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-wrap">
					<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger <?php echo($product_tones_active) ? 'active':'default-value'; ?>">
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value" data-default="All TONES" data-more="0">
							<?php 
							if(!isset($GET_product_tones) || empty($GET_product_tones))  echo 'All TONES';
							elseif(is_array($GET_product_tones)) {
								if(count($GET_product_tones) == 1) echo $GET_product_tones[0];
								else echo $GET_product_tones[0] . ' + 1';
							}
							?>
							
						</span>
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear-wrap">
							<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear">Clear</span>
							<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon themeicon- theme-icon-arrow-forward"></i>
						</span>
					</span>
				</span>
				<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list ps" <?php echo($product_tones_active) ? 'style="display:block;"':''; ?>>
					<?php foreach($product_tones as $product_tone) : ?>
						<?php
						$checked = false;
						if((is_array($GET_product_tones) && in_array($product_tone->slug, $GET_product_tones)) || $GET_product_tones == $product_tone->slug) $checked = true;
						?>
						<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item <?php echo($checked) ? 'checked':''; ?>" data-category-id="<?php echo $product_tone->term_id; ?>">
							<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="checkbox" id="<?php echo $product_tone->term_id; ?>" name="<?php echo $product_tone->name; ?>" value="<?php echo $product_tone->name; ?>" <?php echo($checked) ? 'checked':''; ?>>
							<label for="<?php echo $product_tone->term_id; ?>"><?php echo $product_tone->name; ?></label>
							<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
						</li>
					<?php endforeach; ?>
				</ul>
			</li>
		<?php endif; ?>
		
		
		<?php
		$args = [
			'taxonomy' => 'product_materials',
			'orderby' => 'name',
			'order' => 'ASC',
			'hide_empty' => $hide_empty
		];
		if(!empty($products_ids)) $args['object_ids'] = $products_ids;
		$product_materials = get_terms($args);
		
		
		$GET_product_materials = $_GET["product_materials"];
		if($GET_product_materials || (is_array($GET_product_materials) && !empty($GET_product_materials))) $product_materials_active = true;
		else $product_materials_active = false;
		?>
		<?php if($product_materials) : ?>
			<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item" data-taxonomy-id="product_materials">
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-wrap">
					<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger <?php echo($product_materials_active) ? 'active':'default-value'; ?>">
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value" data-default="all Materials" data-more="0">
							<?php 
							if(!isset($GET_product_materials) || empty($GET_product_materials))  echo 'all Materials';
							elseif(is_array($GET_product_materials)) {
								if(count($GET_product_materials) == 1) echo $GET_product_materials[0];
								else echo $GET_product_materials[0] . ' + 1';
							}
							?>						
						</span>
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear-wrap">
							<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear">Clear</span>
							<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon themeicon- theme-icon-arrow-forward"></i>
						</span>
					</span>
				</span>
				<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list ps" <?php echo($product_materials_active) ? 'style="display:block;"':''; ?>>
					<?php foreach($product_materials as $product_material) : ?>
						<?php
						$checked = false;
						if((is_array($GET_product_materials) && in_array($product_material->slug, $GET_product_materials)) || $GET_product_materials == $product_material->slug) $checked = true;
						?>
						<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item <?php echo($checked) ? 'checked':''; ?>" data-category-id="<?php echo $product_material->term_id; ?>">
							<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="checkbox" id="<?php echo $product_material->term_id; ?>" name="<?php echo $product_material->name; ?>" value="<?php echo $product_material->name; ?>" <?php echo($checked) ? 'checked':''; ?>>
							<label for="<?php echo $product_material->term_id; ?>"><?php echo $product_material->name; ?></label>
							<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
						</li>
					<?php endforeach; ?>
				</ul>
			</li>
		<?php endif; ?>
		
		
		<?php
		$product_finishes = get_terms([
			'taxonomy' => 'product_finishes',
			'orderby' => 'name',
			'order' => 'ASC',
			'object_ids' => $products_ids,
			'hide_empty' => $hide_empty
		]);
		
		$GET_product_finishes = $_GET["product_finishes"];
		if($GET_product_finishes || (is_array($GET_product_finishes) && !empty($GET_product_finishes))) $product_finishes_active = true;
		else $product_finishes_active = false;
		?>
		<?php if($product_finishes) : ?>
			<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item" data-taxonomy-id="product_finishes">
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-wrap">
					<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger <?php echo($product_finishes_active) ? 'active':'default-value'; ?>">
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value" data-default="All Finishes" data-more="0">
							<?php 
							if(!isset($GET_product_finishes) || empty($GET_product_finishes))  echo 'All Finishes';
							elseif(is_array($GET_product_finishes)) {
								if(count($GET_product_finishes) == 1) echo $GET_product_finishes[0];
								else echo $GET_product_finishes[0] . ' + 1';
							}
							?>								
						</span>
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear-wrap">
							<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear">Clear</span>
							<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon themeicon- theme-icon-arrow-forward"></i>
						</span>
					</span>
				</span>
				<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list ps" <?php echo($product_finishes_active) ? 'style="display:block;"':''; ?>>
					<?php foreach($product_finishes as $product_finishe) : ?>
						<?php
						$checked = false;
						if((is_array($GET_product_finishes) && in_array($product_finishe->slug, $GET_product_finishes)) || $GET_product_finishes == $product_finishe->slug) $checked = true;
						?>
						<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item <?php echo($checked) ? 'checked':''; ?>" data-category-id="<?php echo $product_finishe->term_id; ?>">
							<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="checkbox" id="<?php echo $product_finishe->term_id; ?>" name="<?php echo $product_finishe->name; ?>" value="<?php echo $product_finishe->name; ?>" <?php echo($checked) ? 'checked':''; ?>>
							<label for="<?php echo $product_finishe->term_id; ?>"><?php echo $product_finishe->name; ?></label>
							<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
						</li>
					<?php endforeach; ?>
				</ul>
			</li>
		<?php endif; ?>
		
		
		<?php
		$product_sizes = get_terms([
			'taxonomy' => 'product_size',
			'orderby' => 'name',
			'order' => 'ASC',
			'object_ids' => $products_ids,
			'hide_empty' => $hide_empty
		]);
		
		$GET_product_sizes = $_GET["product_sizes"];
		if($GET_product_sizes || (is_array($GET_product_sizes) && !empty($GET_product_sizes))) $product_sizes_active = true;
		else $product_sizes_active = false;
		?>
		<?php if($product_sizes) : ?>
			<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item" data-taxonomy-id="product_size">
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-wrap">
					<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger <?php echo($product_sizes_active) ? 'active':'default-value'; ?>">
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value" data-default="all  sizes" data-more="0">
							<?php 
							if(!isset($GET_product_sizes) || empty($GET_product_sizes))  echo 'all  sizes';
							elseif(is_array($GET_product_sizes)) {
								if(count($GET_product_sizes) == 1) echo $GET_product_sizes[0];
								else echo $GET_product_sizes[0] . ' + 1';
							}
							?>
							
						</span>
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear-wrap">
							<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear">Clear</span>
							<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon themeicon- theme-icon-arrow-forward"></i>
						</span>
					</span>
				</span>
				<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list ps" <?php echo($product_sizes_active) ? 'style="display:block;"':''; ?>>
					<?php foreach($product_sizes as $product_size) : ?>
						<?php
						$checked = false;
						if((is_array($GET_product_sizes) && in_array($product_size->slug, $GET_product_sizes)) || $GET_product_sizes == $product_size->slug) $checked = true;
						?>
						<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item <?php echo($checked) ? 'checked':''; ?>" data-category-id="<?php echo $product_size->term_id; ?>">
							<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="checkbox" id="<?php echo $product_size->term_id; ?>" name="<?php echo $product_size->name; ?>" value="<?php echo $product_size->name; ?>" <?php echo($checked) ? 'checked':''; ?>>
							<label for="<?php echo $product_size->term_id; ?>"><?php echo $product_size->name; ?></label>
							<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
						</li>
					<?php endforeach; ?>
				</ul>
			</li>
		<?php endif; ?>
		
		<?php
		$product_usages = get_terms([
			'taxonomy' => 'product_usages',
			'orderby' => 'name',
			'order' => 'ASC',
			'object_ids' => $products_ids,
			'hide_empty' => $hide_empty
		]);
		
		$GET_product_usages = $_GET["product_usages"];
		if($GET_product_usages || (is_array($GET_product_usages) && !empty($GET_product_usages))) $product_usages_active = true;
		else $product_usages_active = false;
		?>
		<?php if($product_usages) : ?>
			<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item" data-taxonomy-id="product_usages">
				<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-wrap">
					<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger  <?php echo($product_usages_active) ? 'active':'default-value'; ?>">
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value" data-default="All  usages" data-more="0">
							<?php 
							if(!isset($GET_product_usages) || empty($GET_product_usages))  echo 'All usages';
							elseif(is_array($GET_product_usages)) {
								if(count($GET_product_usages) == 1) echo $GET_product_usages[0];
								else echo $GET_product_usages[0] . ' + 1';
							}
							?>
							
						</span>
						<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear-wrap">
							<span class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear">Clear</span>
							<i class="elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon themeicon- theme-icon-arrow-forward"></i>
						</span>
					</span>
				</span>
				<ul class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list ps" <?php echo($product_usages_active) ? 'style="display:block;"':''; ?>>
					<?php foreach($product_usages as $product_usage) : ?>
						<?php
						$checked = false;
						if((is_array($GET_product_usages) && in_array($product_usage->slug, $GET_product_usages)) || $GET_product_usages == $product_usage->slug) $checked = true;
						?>
						<li class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item <?php echo($checked) ? 'checked':''; ?>" data-category-id="<?php echo $product_usage->term_id; ?>">
							<input class="elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox" type="checkbox" id="<?php echo $product_usage->term_id; ?>" name="<?php echo $product_usage->name; ?>" value="<?php echo $product_usage->name; ?>" <?php echo($checked) ? 'checked':''; ?>>
							<label for="<?php echo $product_usage->term_id; ?>"><?php echo $product_usage->name; ?></label>
							<i class="checkbox-icon full themeicon- theme-icon-chech-line"></i>
						</li>
					<?php endforeach; ?>
				</ul>
			</li>
		<?php endif; ?>
	</ul>
</div>
