jQuery(function($) {
	/*STONE Search*/
	function start_search() {
		var s_word = $('#stone_search').val();
		s_word = s_word.trim();
		if(s_word.length > 2) {
			var data = {
				'action': 'stone_search_items',
				's_word': s_word
			};
			$.ajax({
				type: "POST",
				url: '/wp-admin/admin-ajax.php',
				data: data,
				beforeSend : function(){
					$('.search-bar svg.lupa').hide();
					$('.search-bar svg.searching').show();
				},
				success: function (response) {
					$('#search__results').html(response);
					$('.search__popup_wrapper').addClass('search-have--results');
					$('.search-bar svg.searching').hide();
					$('.search-bar svg.clear').show();
				}
			});
		}
	}
	
	
	function search_start_event(evt) {
		const tag = evt.target.value;
		if(evt.key =='Enter' || evt.key == 13) {
			start_search();
		} 
		else if (evt.key == "Backspace" || evt.key == 8) {
			if (tag == "") { // If empty
				$('#search__results').html('');
			}
		}
	}
	
	$('.search__popup_wrapper > i').on('click', function() {
		$('.search__popup_wrapper').toggleClass('search--open');
		$('.search__popup_wrapper').removeClass('search-have--results');
		$('#stone_search').focus();
	})
	$('.search__popup_bg, .search__popup_close').on('click', function() {
		$('.search__popup_wrapper').toggleClass('search--open');
		$('.search__popup_wrapper').toggleClass('search-have--results');
	})
	
	$('#stone_search').on('keydown', search_start_event);
	$('.search-bar svg.lupa').on('click', start_search);
	$('.search-bar svg.clear').on('click', function() {
		$('#search__results').html('');
		$('#stone_search').val('');
		$('.search-bar svg.clear').hide();
		$('.search-bar svg.lupa').show();
		$('.search__popup_wrapper').removeClass('search-have--results');
	});
	$('.search-bar').on('submit', function(e) {
		e.preventDefault();
	})	
	/**/
	
	
	/*Products Sheet Filters*/
	$('.product-sheet .product-page-filter-item .filter-button').on('click', function() {
		var filter_body = $(this).parents('.product-page-filter-item');
		var count = filter_body.find('input:checked').length;
		
		var filter_items = new Object();
		
		$('.product-sheet .product-page-filter-item').each(function() {
			var filter_by = $(this).data('filter-by');
			filter_items[filter_by] = new Array();
			$(this).find('input:checked').each(function() {
				filter_items[filter_by].push($(this).val());
			})	
		})
		
		var data = {
			'action': 'stone_filter_products',
			'filters': filter_items
		};
		$.ajax({
			type: "POST",
			url: '/wp-admin/admin-ajax.php',
			data: data,
			beforeSend : function(){
				filter_body.find('.title').toggleClass('active');
				filter_body.find('.product-page-filter-body').slideToggle();  
				$('#products--filter-response').addClass('loading');
				
				//filter_body.find('.title span').text('').attr('data-count', count);
			},
			success: function (response) {
				$('#products--filter-response').removeClass('loading');
				$('#products--filter-response').html(response);
			}
		});
	})
	
	
	/*designer projects Filters*/
	$('.designer-projects-filter .product-page-filter-item .filter-button').on('click', function() {
		var filter_body = $(this).parents('.product-page-filter-item');
		var count = filter_body.find('input:checked').length;
		var filter_items = new Object();
		
		
		$('.designer-projects-filter .product-page-filter-item').each(function() {
			var filter_by = $(this).data('filter-by');
			if(filter_by) {
				filter_items[filter_by] = new Array();
				$(this).find('input:checked').each(function() {
					filter_items[filter_by].push($(this).val());
				})	
			}			
		})
		
		var sortby = $('.designer-projects-filter .product-page-filter-item.sortby input:checked').val();
		
		var data = {
			'action': 'stone_filter_designer_projects',
			'designer_id' : Number($('#designer_id').val()),
			'filters': filter_items,
			'sortby' : sortby
		};
		

		$.ajax({
			type: "POST",
			url: '/wp-admin/admin-ajax.php',
			data: data,
			beforeSend : function(){
				filter_body.find('.title').toggleClass('active');
				filter_body.find('.product-page-filter-body').slideToggle();  
				$('#projects--filter-response').addClass('loading');
				
				//filter_body.find('.title span').attr('data-count', count);
			},
			success: function (response) {
				$('#projects--filter-response').removeClass('loading');
				$('#projects--filter-response').html(response);
			}
		});
	});
	
	
	/*Collection Filters*/
	$('.collections-filter .product-page-filter-item .filter-button').on('click', function() {
		var filter_body = $(this).parents('.product-page-filter-item');
		var count = filter_body.find('input:checked').length;
		var filter_items = new Object();
		
		
		$('.collections-filter .product-page-filter-item').each(function() {
			var filter_by = $(this).data('filter-by');
			if(filter_by) {
				filter_items[filter_by] = new Array();
				$(this).find('input:checked').each(function() {
					filter_items[filter_by].push($(this).val());
				})	
			}			
		})
		
		var sortby = $('.collections-filter .product-page-filter-item.sortby input:checked').val();
		
		var data = {
			'action': 'stone_collection_filter',
			'collection_slug' : $('#collection_slug').val(),
			'filters': filter_items,
			'sortby' : sortby
		};
		

		$.ajax({
			type: "POST",
			url: '/wp-admin/admin-ajax.php',
			data: data,
			beforeSend : function(){
				filter_body.find('.title').toggleClass('active');
				filter_body.find('.product-page-filter-body').slideToggle();  
				$('#products').addClass('loading');
			},
			success: function (response) {
				$('#products').removeClass('loading');
				$('#products').html(response);
			}
		});
	})
	
	
	$('.product-page-filter-item .checked-item label').on('click', function() {
		var filter_body = $(this).parents('.product-page-filter-item');
		

		setTimeout(function() {
			var count = filter_body.find('input:checked').length;
			if(count == 0) {
				var d_t = filter_body.find('.title').data('default-title');
				filter_body.find('.title span').text(d_t);
				filter_body.find('.title span').attr('data-count', '0');
			}
			else if(count == 1) {
				filter_body.find('.title span').attr('data-count', '0');
				var f_el = filter_body.find('input:checked').next('label').text();
				filter_body.find('.title span').text(f_el);
			}
			else if(count > 1) {
				filter_body.find('.title span').attr('data-count', (count - 1));
			}
			
			if(count >= 1) {
				$('.advanced-filters .filter-submit').prop('disabled', false);
			}
			else $('.advanced-filters .filter-submit').prop('disabled', true);
			
		},100)
	
	})
	
	/**Product Filter**/
	
	function collect_filter_data() {
		var container = $('.stone__products_list.products_list .elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list');
		var data = new Object();
		container.find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item').each(function() {
			var filter_by = $(this).data('taxonomy-id');
			var values = new Array();
			$(this).find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list .elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item .elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item-checkbox:checked').each(function() {
				
				values.push($(this).parent('li').data('category-id'));
			});
			data[filter_by] = values;
		});
		
		
		return data;
	}
	
	
	function products_filter(task) {
		var filter_data = collect_filter_data();
		
		var data = {
			'action': 'filter_products',
			'filters': filter_data,
			'page' : Number($('input#page').val()),
		};
		
		
	
		$.ajax({
			type: "POST",
			url: '/wp-admin/admin-ajax.php',
			data: data,
			dataType: 'json',
			beforeSend : function(){
				$('#filter-products-response').addClass('loading');
				if(task == 'load_more') {
					$('.load_more_products--button').addClass('disabled').text($('.load_more_products--button').data('loading-text'));
				}
			},
			success: function (response) {
				$('#filter-products-response').removeClass('loading');
				if(task == 'filter') {
					$('#filter-products-response').html(response.html);
					$('#max-pages').val(response.max_pages);
					if(response.max_pages == 1) $('.load_more_products--button').hide();
					else $('.load_more_products--button').show();
					
					$('.found_posts__wrapper span').text(response.found_posts)
				}
				else {
					$('#filter-products-response').append(response.html);
					$('.load_more_products--button').removeClass('disabled').text($('.load_more_products--button').data('default-text'));
					var page = Number($('input#page').val());
					if(page == Number($('#max-pages').val())) $('.load_more_products--button').hide();
					else $('.load_more_products--button').show();
				}
				
				
			}
		});
	}
	
	
	$('.load_more_products--button').on('click', function(e) {
		e.preventDefault();
		var page = Number($('input#page').val());
		var next_page = page + 1;
		
		$('input#page').val(next_page);
		
		setTimeout(function() {
			products_filter('load_more');
		}, 100)
	})
	
	
	$('.products_list.stone__products_list .elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value, .elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-icon').on('click', function() {	
		$(this).parents('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger').toggleClass('active');
		var $trigger_p = $(this).parents('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item');
		$trigger_p.find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list').fadeToggle();
	});
	
	$('.products_list.stone__products_list .elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-clear').on('click', function() {	
		var ul = $(this).parents('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item').find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list');
		ul.fadeToggle();
		ul.find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item').removeClass('checked');
		ul.find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item input').prop('checked', false);
		$(this).parents('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger').removeClass('active').addClass('default-value');
		
		setTimeout(function() {
			products_filter('filter');
		}, 100);
	});
	
	$('.products_list.stone__products_list .elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list .elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item label').on('click', function() {	
		var _this = $(this);
		var _this_text = _this.text();
		var $li = _this.parent('.elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list-item');
		$li.toggleClass('checked');
		
		$('input#page').val(1);
		
		setTimeout(function() {
			var parent_ul = _this.parents('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item');
			var ul = _this.parents('.elementor-widget-cmsmasters-theme-blog-grid__multiple-category-list');
			var trigger = parent_ul.find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger-value');
			var count = ul.find('input:checked').length;
			
			if(count == 0) {
				parent_ul.find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger').addClass('default-value');
				trigger.text(trigger.data('default'));
			}
			else if(count == 1) {
				parent_ul.find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger').removeClass('default-value');
				trigger.data('new-value', _this_text);
				trigger.data('more', 1);
				trigger.text(ul.find('input:checked').eq(0).next('label').text());
			}
			else if(count > 1) {
				parent_ul.find('.elementor-widget-cmsmasters-theme-blog-grid__multiple-taxonomy-list-item-trigger').removeClass('default-value');
				trigger.data('more', count);
				var first_el_name = ul.find('input:checked').eq(0).next('label').text();
				trigger.text(first_el_name + ' + ' + (count - 1));
				
			}
			
			products_filter('filter');
			
			
		}, 100)				   
	});
})
